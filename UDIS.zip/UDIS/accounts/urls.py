from django.urls import path
from . import views

urlpatterns = [
	path('register/', views.register, name = 'register'),
	path('login/', views.login_user, name = 'login_user'),
	path('logout/', views.logout_user, name = 'logout_user'),
        path('student/home/', views.student_home, name = 'student_home'),
        path('faculty/home/', views.faculty_home, name = 'faculty_home'),
        path('secretary/home/', views.secretary_home, name = 'secretary_home'),
	path('student-register/', views.student_register.as_view(), name = 'student_register'),
	path('faculty-register/', views.faculty_register.as_view(), name = 'faculty_register'),
        path('secretary-register/', views.secretary_register.as_view(), name = 'secretary_register'),
]
